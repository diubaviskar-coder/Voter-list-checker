// app.js
// Requires: papaparse and localforage loaded via CDN in index.html

// Storage keys
const VOTERS_KEY = 'voters_v1';
const SPLASH_KEY = 'splash_v1';
const FILE_PREFIX = 'file_'; // files stored separately in localforage

// localforage setup (uses IndexedDB under the hood)
localforage.config({ name: 'VoterListManager' });
const filesStore = localforage.createInstance({ name: 'VoterFiles' });

// DOM elements
const splashImg = document.getElementById('splash-img');
const changeSplashInput = document.getElementById('change-splash-input');
const resetSplashBtn = document.getElementById('reset-splash');
const searchInput = document.getElementById('search');
const clearSearchBtn = document.getElementById('clear-search');
const importInput = document.getElementById('import-input');
const exportBtn = document.getElementById('export-btn');
const clearAllBtn = document.getElementById('clear-all-btn');
const listEl = document.getElementById('list');
const countEl = document.getElementById('count');

const newName = document.getElementById('new-name');
const newNote = document.getElementById('new-note');
const attachFileInput = document.getElementById('attach-file-input');
const addRecordBtn = document.getElementById('add-record-btn');
const attachedFilename = document.getElementById('attached-filename');

let attachedFile = null; // File object selected for new record
let voters = []; // local cache

// default splash (data URI tiny placeholder)
const defaultSplashData = 'data:image/svg+xml;utf8,' + encodeURIComponent(
  `<svg xmlns="http://www.w3.org/2000/svg" width="800" height="400"><rect width="100%" height="100%" fill="#e8f2ff"/><text x="50%" y="50%" dominant-baseline="middle" text-anchor="middle" fill="#1a73e8" font-size="32">Voter List Manager</text></svg>`
);

// --- init ---
async function init(){
  // load splash
  const s = await localforage.getItem(SPLASH_KEY);
  if(s){
    splashImg.src = s;
  } else {
    splashImg.src = defaultSplashData;
  }

  // load voters
  const saved = await localforage.getItem(VOTERS_KEY);
  voters = Array.isArray(saved) ? saved : [];
  renderList(voters);
}

// --- helper: save voters ---
async function saveVoters(){
  await localforage.setItem(VOTERS_KEY, voters);
}

// --- render list ---
function renderList(arr){
  listEl.innerHTML = '';
  countEl.textContent = arr.length;
  if(!arr || arr.length === 0){
    listEl.innerHTML = `<div class="muted">No records. Use Import or Add New Voter.</div>`;
    return;
  }
  arr.forEach(v => {
    const item = document.createElement('div');
    item.className = 'item';

    const left = document.createElement('div');
    left.className = 'left';

    // thumbnail if file image exists
    const thumb = document.createElement('img');
    thumb.className = 'thumb';
    thumb.src = v.fileThumb || defaultThumbFor(v);
    thumb.alt = '';

    const meta = document.createElement('div');
    const nm = document.createElement('div');
    nm.className = 'name';
    nm.textContent = v.name;
    const note = document.createElement('div');
    note.className = 'note';
    note.textContent = v.note || '';

    meta.appendChild(nm);
    meta.appendChild(note);

    left.appendChild(thumb);
    left.appendChild(meta);

    const actions = document.createElement('div');
    actions.className = 'actions';

    const openBtn = document.createElement('button');
    openBtn.className = 'small-link';
    openBtn.textContent = v.fileKey ? 'Open File' : 'No File';
    openBtn.disabled = !v.fileKey;
    openBtn.onclick = () => openFile(v);

    const delBtn = document.createElement('button');
    delBtn.className = 'small-link';
    delBtn.textContent = 'Delete';
    delBtn.style.color = '#d23';
    delBtn.onclick = () => deleteRecord(v.id);

    actions.appendChild(openBtn);
    actions.appendChild(delBtn);

    item.appendChild(left);
    item.appendChild(actions);

    listEl.appendChild(item);
  });
}

function defaultThumbFor(v){
  return defaultSplashData;
}

// --- search handler (simple client-side) ---
searchInput.addEventListener('input', (e) => {
  const q = e.target.value.trim().toLowerCase();
  if(!q) return renderList(voters);
  const res = voters.filter(v => (v.name || '').toLowerCase().includes(q));
  renderList(res);
});
clearSearchBtn.addEventListener('click', () => { searchInput.value=''; renderList(voters); });

// --- import CSV/JSON ---
importInput.addEventListener('change', async (ev) => {
  const f = ev.target.files[0];
  if(!f) return;
  const fname = f.name.toLowerCase();
  try{
    const text = await f.text();
    let records = [];
    if(fname.endsWith('.json')){
      records = JSON.parse(text);
    } else {
      const parsed = Papa.parse(text, { header: true, skipEmptyLines: true });
      records = parsed.data;
    }
    // normalize and insert
    let inserted = 0;
    const now = Date.now();
    for(const r of records){
      const name = (r.name || r.Name || '').toString().trim();
      const note = (r.note || r.Note || r.booth || r.info || '').toString();
      if(name){
        voters.unshift({ id: now + Math.random(), name, note, fileKey: null, fileThumb: null });
        inserted++;
      }
    }
    await saveVoters();
    renderList(voters);
    alert(`Imported approx ${inserted} records.`);
  } catch(err){
    console.error(err);
    alert('Import failed: check file format.');
  } finally {
    importInput.value = '';
  }
});

// --- export CSV ---
exportBtn.addEventListener('click', async () => {
  if(!voters || voters.length === 0){ alert('No data to export'); return; }
  const data = voters.map(({id,name,note}) => ({id,name,note}));
  const csv = Papa.unparse(data);
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'voters_export.csv';
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
});

// --- add new record with optional file ---
attachFileInput.addEventListener('change', (ev) => {
  const f = ev.target.files[0];
  if(!f) { attachedFile = null; attachedFilename.textContent = ''; return; }
  attachedFile = f;
  attachedFilename.textContent = `Attached: ${f.name}`;
});

addRecordBtn.addEventListener('click', async () => {
  const name = (newName.value || '').trim();
  if(!name){ alert('Name required'); return; }
  const note = (newNote.value || '').trim();
  let fileKey = null, thumbData = null;
  if(attachedFile){
    // read as arraybuffer and save in filesStore
    const id = 'f_' + Date.now() + '_' + Math.random().toString(36).slice(2,8);
    try{
      const dataUrl = await readFileAsDataURL(attachedFile);
      await filesStore.setItem(id, { name: attachedFile.name, type: attachedFile.type, dataUrl });
      fileKey = id;
      // small thumb for images
      if(attachedFile.type && attachedFile.type.startsWith('image/')){
        thumbData = dataUrl;
      }
    } catch(e){
      console.error(e);
    }
  }
  const rec = { id: Date.now() + Math.random(), name, note, fileKey, fileThumb: thumbData };
  voters.unshift(rec);
  await saveVoters();
  // clear inputs
  newName.value=''; newNote.value=''; attachedFile=null; attachFileInput.value=''; attachedFilename.textContent='';
  renderList(voters);
});

// --- open file (download or open in new tab) ---
async function openFile(v){
  if(!v.fileKey){ alert('No file'); return; }
  try{
    const meta = await filesStore.getItem(v.fileKey);
    if(!meta) { alert('File not found'); return; }
    // open dataUrl in new tab
    const win = window.open('');
    // create embed depending on type
    if(meta.type && meta.type.startsWith('image/')){
      win.document.write(`<img src="${meta.dataUrl}" style="max-width:100%;height:auto">`);
    } else if(meta.type === 'application/pdf'){
      win.document.write(`<embed src="${meta.dataUrl}" type="application/pdf" width="100%" height="100%"></embed>`);
    } else {
      // fallback: show download link
      const a = win.document.createElement('a');
      a.href = meta.dataUrl;
      a.download = meta.name;
      a.textContent = 'Download file';
      win.document.body.appendChild(a);
    }
  } catch(e){
    console.error(e);
    alert('Cannot open file');
  }
}

// --- delete record ---
async function deleteRecord(id){
  if(!confirm('Are you sure to delete this record?')) return;
  const idx = voters.findIndex(v => v.id === id);
  if(idx === -1) return;
  const removed = voters.splice(idx,1)[0];
  // also remove file if any
  if(removed && removed.fileKey){
    await filesStore.removeItem(removed.fileKey).catch(()=>{});
  }
  await saveVoters();
  renderList(voters);
}

// --- change splash ---
changeSplashInput.addEventListener('change', async (ev) => {
  const f = ev.target.files[0];
  if(!f) return;
  if(!f.type.startsWith('image/')) { alert('Select an image'); changeSplashInput.value=''; return; }
  try{
    const dataUrl = await readFileAsDataURL(f);
    // persist splash in localforage
    await localforage.setItem(SPLASH_KEY, dataUrl);
    splashImg.src = dataUrl;
    alert('Splash updated');
  } catch(e){
    console.error(e);
  } finally {
    changeSplashInput.value='';
  }
});
resetSplashBtn.addEventListener('click', async () => {
  await localforage.removeItem(SPLASH_KEY);
  splashImg.src = defaultSplashData;
});

// --- clear all ---
clearAllBtn.addEventListener('click', async () => {
  if(!confirm('Clear all voter records and files?')) return;
  voters = [];
  await saveVoters();
  // clear files store
  await filesStore.clear();
  renderList(voters);
});

// --- utility ---
function readFileAsDataURL(file){
  return new Promise((resolve,reject)=>{
    const fr = new FileReader();
    fr.onload = ()=> resolve(fr.result);
    fr.onerror = reject;
    fr.readAsDataURL(file);
  });
}

// init app
init();
